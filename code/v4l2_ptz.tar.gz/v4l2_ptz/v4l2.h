#ifndef V4L2_H
#define V4L2_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/mman.h>       //for map_shared
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>
#include <stdint.h>
#include <linux/videodev2.h>
#include <error.h>
#include <unistd.h>



#define NB_BUFFER 4
#define device "/dev/video0"    //  摄像头设备文件

/*这个大的节构体是保存摄像头的信息*/
struct video_information
{
    int fd;     //descriptor
    struct v4l2_capability cap;
    struct v4l2_format fmt;//这个设备的功能，比如是否是视频输入设备
    struct v4l2_requestbuffers rb; //M E M O R Y - M A P P I N G   B U F F E R S
    struct v4l2_buffer buf; //代表驱动中的一祯
    enum v4l2_buf_type type;
    struct v4l2_streamparm parm;

    void *mem[NB_BUFFER];       //MAIN BUFFERS

    unsigned char* tmp_buffer;          //for mjpeg
    unsigned char* frame_buffer;        //one frame buffer here
    unsigned int frame_size_in;

    unsigned int format;              //YUYV or MJPEG
    int width;
    int height;
    int is_streaming;           //start capture
    int is_quit;

    enum v4l2_field field;
    unsigned int bytes_per_line;
    unsigned int size_image;
    enum v4l2_colorspace color_space;
    unsigned int priv;
};



class V4l2
{
public:
    V4l2();

public:
    /*在开始采集数据前,需要先看一下摄像头的信息,下面三个函数完成的功能分别为得到摄像头的屬性,
    得到摄像头的格式,設置摄像头的格式*/
    int v4l2_get_capability(struct video_information* vd_info);
    int v4l2_get_format(struct video_information* vd_info);
    int v4l2_set_format(struct video_information* vd_info,unsigned int width,unsigned int height,unsigned int format);
    /*打开,用阻塞方式打开.*/
    /*关于阻塞和非阻塞模式__如果使用非阻塞模式调用视频设备,即使尚未捕获到信息,驱动依旧会把缓存里的东西返回给应用程序*/
    int v4l2_open(struct video_information* vd_info);
    /*关閉设备(释放内存,关閉设备)*/
    int v4l2_close(struct video_information* vd_info);

    /*init the camera*/
    int v4l2_init(struct video_information* vd_info,unsigned int format,unsigned int width,unsigned int height);




    /*开始和停止捕获设备,(发送开始,停止信号)*/
    int v4l2_on(struct video_information* vd_info);
    int v4l2_off(struct video_information* vd_info);




    int v4l2_grab(struct video_information* vd_info);

    int v4l2_just_close(struct video_information* vd_info);
    /*设置流参数*/
    int v4l2_set_streamParam(struct video_information* vd_info);
private:
};

#endif // V4L2_H
