#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "assert.h"
#include <sys/ioctl.h>
#include <sys/mman.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
 #include <fcntl.h>
#include <linux/videodev2.h>
#include <QDebug>


MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	isRunning(false),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);

    char device[20];
    //sprintf(device, "/dev/video%d", (int) _deviceId);

    int fd = 0;
    int i = 0;
    /* detect /dev/video [0-63] entries */
    for (int n = 0; n < 64; n++)
    {
        memset(device, 0, 20);
        sprintf(device, "/dev/video%d", n);
        if ((fd = open(device, O_RDONLY)) != -1)
        {
            // query device capabilities
            struct v4l2_capability cap;
            if (ioctl(fd, VIDIOC_QUERYCAP, &cap) == 0)
            {
                ::close(fd);

                printf("Slect video  device %s\n", device);
                ui->videoselect->insertItem(i, device);
                i++;
                continue; // fd matches with device unique id supplied
            }
            ::close(fd); // close since this is not the matching device
        }
    }


}

MainWindow::~MainWindow()
{
	delete ui;
}


void MainWindow::on_opencamera_clicked()
{
    if(isRunning)
    {
        return;
    }

   mysdl = new SDL;

   webrtc_v4l2 = new webrtc::VideoCaptureModuleV4L2(0, mysdl, this);

   QString device_name = ui->videoselect->currentText();

   webrtc_v4l2->StartCapture(device_name.toStdString().c_str(), 0, 1920, 1080);

   isRunning = true;
}

void MainWindow::on_closecamera_clicked()
{
    if(!isRunning)
    {
        return;
    }

	isRunning = false;

    webrtc_v4l2->StopCapture();

    mysdl->sdl_uninit();

    delete mysdl;
    delete webrtc_v4l2;
}

void MainWindow::on_up_clicked()
{

}



void MainWindow::on_right_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "pan");

    myctrl.value = 10;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}

void MainWindow::on_rightstop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "pan");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }
}

void MainWindow::on_home_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "home");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}

void MainWindow::on_upstart_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "tilt");

    myctrl.value = 10;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }


}
void MainWindow::on_upstop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "tilt");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}

void MainWindow::on_leftstart_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "pan");

    myctrl.value = -10;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }
}


void MainWindow::on_leftstop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "pan");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}



void MainWindow::on_downstart_clicked()
{

    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "tilt");

    myctrl.value = -10;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }
}

void MainWindow::on_downstop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "tilt");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}

void MainWindow::on_zoomIn_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "zoom");

    myctrl.value = 1;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }
}
void MainWindow::on_zoomInStop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "zoom");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}


void MainWindow::on_zoomOut_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "zoom");

    myctrl.value = -1;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }

}


void MainWindow::on_zoomOutStop_clicked()
{
    if(!isRunning)
    {
        return;
    }
    stCameraPTZ myctrl;

    memset(&myctrl, 0, sizeof(stCameraPTZ));
    strcpy(myctrl.current_ctrl_type, "zoom");

    myctrl.value = 0;

    if(webrtc_v4l2)
    {
        webrtc_v4l2->setCameraCtrl(myctrl);
    }
}
 int MainWindow::yuv_callback(unsigned char * buffer, int len,int w, int h)
 {
     emit sigYuv(buffer, w, h);
     return 0;
 }
