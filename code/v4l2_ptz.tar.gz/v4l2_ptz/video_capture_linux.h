/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#ifndef WEBRTC_MODULES_VIDEO_CAPTURE_MAIN_SOURCE_LINUX_VIDEO_CAPTURE_LINUX_H_
#define WEBRTC_MODULES_VIDEO_CAPTURE_MAIN_SOURCE_LINUX_VIDEO_CAPTURE_LINUX_H_

#include "webrtc/common_types.h"
#include "webrtc/system_wrappers/interface/tick_util.h"

#include "do_sdl.h"

#include <assert.h>
#include <string>
#include<iostream> 
#include<deque>
using namespace std;

#define V4L2_CID_PAN_SPEED          (V4L2_CID_CAMERA_CLASS_BASE+32)
#define V4L2_CID_TILT_SPEED         (V4L2_CID_CAMERA_CLASS_BASE+33)
#define V4L2_CID_PANTILT_RELATIVE   (V4L2_CID_CAMERA_CLASS_BASE+34)
#define V4L2_CID_FOCUS_FAR_NEAR     (V4L2_CID_CAMERA_CLASS_BASE+35)

enum {kDefaultWidth = 640};  // Start width
enum {kDefaultHeight = 480}; // Start heigt
enum {kDefaultFrameRate = 30}; // Start frame rate

enum {kMaxFrameRate =60}; // Max allowed frame rate of the start image 

enum {kDefaultCaptureDelay = 120}; 
enum {kMaxCaptureDelay = 270}; // Max capture delay allowed in the precompiled capture delay values.  

enum {kProcessInterval = 300}; 
enum {kFrameRateCallbackInterval = 1000}; 
enum {kFrameRateCountHistorySize = 90};
enum {kFrameRateHistoryWindowMs = 2000};




typedef struct CameraPTZ
{   
	char current_ctrl_type[5];
	int value;
} stCameraPTZ;

class YuvCallBack{
public:
    YuvCallBack(){

    }

    virtual int yuv_callback(unsigned char * buffer, int len, int w, int h) = 0;

};


namespace webrtc
{
class CriticalSectionWrapper;
class ThreadWrapper;

class VideoCaptureModuleV4L2
{
public:
    VideoCaptureModuleV4L2(int32_t id, SDL *sdl,YuvCallBack *yuv);
    virtual ~VideoCaptureModuleV4L2();
    virtual int32_t Init(const char* deviceUniqueId);
    virtual int32_t StartCapture(const char* device_name, unsigned int format,unsigned int width,unsigned int height);
    virtual int32_t StopCapture();
    virtual bool CaptureStarted();


    int setCameraCtrl(stCameraPTZ myctrl);

private:
    enum {kNoOfV4L2Bufffers=4};

    static bool CaptureThread(void*);
    bool CaptureProcess();
    bool AllocateVideoBuffers();
    bool DeAllocateVideoBuffers();

    ThreadWrapper* _captureThread;
    CriticalSectionWrapper* _captureCritSect;
	CriticalSectionWrapper* _cameraCtrlCritsect;

    int32_t _deviceId;
    int32_t _deviceFd;

    int32_t _buffersAllocatedByDevice;
    int32_t _currentWidth;
    int32_t _currentHeight;
    int32_t _captureVideoType;
    int32_t _currentFrameRate;
    bool _captureStarted;

    struct Buffer
    {
        void *start;
        size_t length;
    };
    uint64_t _incomingFrameTimes[kFrameRateCountHistorySize];// timestamp for local captured frames
    uint64_t  _lastFrameRateCallbackTime; // last time the frame rate callback function was called.
    void UpdateFrameCount();
    uint32_t CalculateFrameRate(const TickTime& now);
    Buffer *_pool;
	uint32_t  _curCalcFrameRate;
    int32_t _id;

    SDL   * mysdl;

	std::deque<stCameraPTZ> camera_ptz;

    YuvCallBack *_yuv;

};

}  // namespace webrtc

#endif // WEBRTC_MODULES_VIDEO_CAPTURE_MAIN_SOURCE_LINUX_VIDEO_CAPTURE_LINUX_H_
