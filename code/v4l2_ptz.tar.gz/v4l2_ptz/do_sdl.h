#ifndef SDL_DO_H_
#define SDL_DO_H_
extern "C"
{
#include "sdl/sdl2/include/SDL2.0.8/SDL.h"
#include "sdl/sdl2image/include/SDL2/SDL_image.h"
#undef main
}


class SDL
{
 public:
    SDL();
    ~SDL();
    int sdl_init(int32_t _captureVideoType, int width, int height);
    int sdl_uninit();

    int sdl_showMovie(unsigned char * buffer, int len);

    int draw_yuyv(unsigned char * buffer, int len);
    int draw_mjpeg(unsigned char * buffer, int len);

private:

    SDL_Event sdlevent;

    unsigned char frmrate;
    unsigned int currtime;
    unsigned int lasttime;

    SDL_Window *window;
    SDL_Renderer * renderer;
    SDL_Texture * texture;

    int32_t m_captureVideoType;


    char *status;
    int cur_w;
    int cur_h;

    FILE * FP_YUV;

};

#endif
