#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "video_capture_linux.h"
#include "do_sdl.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow, public YuvCallBack
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    int yuv_callback(unsigned char * buffer, int len,int w, int h);

signals:
    void sigYuv(uchar * buffer, int w, int h);

private slots:


    void on_opencamera_clicked();

    void on_closecamera_clicked();

    void on_up_clicked();


    void on_right_clicked();

    void on_rightstop_clicked();

    void on_home_clicked();

    void on_upstart_clicked();
    void on_upstop_clicked();

    void on_leftstart_clicked();



    void on_leftstop_clicked();

    void on_downstart_clicked();

    void on_downstop_clicked();

    void on_zoomIn_clicked();

    void on_zoomOut_clicked();

    void on_zoomInStop_clicked();

    void on_zoomOutStop_clicked();

private:
    Ui::MainWindow *ui;
	
	bool isRunning;
    webrtc::VideoCaptureModuleV4L2 *webrtc_v4l2;
    SDL * mysdl;

};

#endif // MAINWINDOW_H
