#include "v4l2.h"
#include <iostream>
using namespace std;
extern "C"
{
#include "utils.h"
}

V4l2::V4l2()
{

}

int V4l2::v4l2_get_capability(struct video_information *vd_info)
{
    memset(&vd_info->cap,0,sizeof(struct v4l2_capability));
    if(ioctl(vd_info->fd,VIDIOC_QUERYCAP,&(vd_info->cap)))
    {
        perror("get_capability:");
        return -1;
    }
    return 0;
}

int V4l2::v4l2_get_format(struct video_information *vd_info)
{
    memset(&vd_info->fmt,0,sizeof(struct v4l2_format));
    vd_info->fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if(ioctl(vd_info->fd,VIDIOC_G_FMT,&(vd_info->fmt)))
    {
        perror("get_format:");
        return -1;
    }
    vd_info->format = vd_info->fmt.fmt.pix.pixelformat;
    //pixelformat is 32 bit,it is easy to get the code for a interge
    /*char code[5];
    for(i=0; i<4; i++)
    {
        code[i] = (vd_info->format & (0xff<<i*8))>>i*8;
    }*/

    vd_info->width = vd_info->fmt.fmt.pix.width;
    vd_info->height = vd_info->fmt.fmt.pix.height;
    vd_info->field = (v4l2_field)vd_info->fmt.fmt.pix.field;
    vd_info->bytes_per_line = vd_info->fmt.fmt.pix.bytesperline;
    vd_info->size_image = vd_info->fmt.fmt.pix.sizeimage;
    vd_info->color_space = (v4l2_colorspace)vd_info->fmt.fmt.pix.colorspace;
    vd_info->priv = vd_info->fmt.fmt.pix.priv;

    return 0;
}

int V4l2::v4l2_set_format(struct video_information *vd_info, unsigned int width, unsigned int height, unsigned int format)
{
	memset(&vd_info->fmt,0,sizeof(struct v4l2_format));
	vd_info->fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	vd_info->fmt.fmt.pix.width = width;
	vd_info->fmt.fmt.pix.height = height;
	vd_info->fmt.fmt.pix.pixelformat = format;
	vd_info->fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;

	v4l2_std_id std;
	int ret;
	do
	{
		ret=ioctl(vd_info->fd,VIDIOC_QUERYSTD,&std);

	}while(ret==-1 && errno==EAGAIN);

	switch(std)
	{
		case V4L2_STD_NTSC: 
			cout<<"ntsc"; 
			break;
		case V4L2_STD_PAL:  
			cout<<"pal";
			break;
		default: 
			cout<<"bu zhi dao="<<hex<<(__u64)std<<endl;
			printf("xx=%ld\n",(__u64)std);
	}

	/*设置视频针格式.*/
	if(ioctl(vd_info->fd,VIDIOC_S_FMT,&(vd_info->fmt)))
	{
		perror("set_format:xx");
		return -1;
	}
    return 0;
}

int V4l2::v4l2_set_streamParam(struct video_information *vd_info)
{
    memset(&vd_info->parm,0,sizeof(struct v4l2_streamparm));
    vd_info->parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    vd_info->parm.parm.capture.timeperframe.denominator = 10;
    vd_info->parm.parm.capture.timeperframe.numerator = 1;
    vd_info->parm.parm.output.timeperframe.denominator = 10;
    vd_info->parm.parm.output.timeperframe.numerator = 1;
    if(-1 == ioctl(vd_info->fd,VIDIOC_S_PARM,&vd_info->parm))
    {
        perror("set param:");
        return -1;
    }
    printf("the frame rate:%d\n",vd_info->parm.parm.output.timeperframe.denominator);
    return 0;
}

int V4l2::v4l2_open(struct video_information *vd_info)
{
    vd_info->fd = open(device,O_RDWR,0);
    if(vd_info->fd < 0)
    {
        perror("open:");
        return -1;
    }
    return 0;
}

int V4l2::v4l2_close(struct video_information *vd_info)
{
    unsigned short i = 0;
    if(vd_info->is_streaming)
        v4l2_off(vd_info);

    if(vd_info->frame_buffer)
        free(vd_info->frame_buffer);
    if(vd_info->tmp_buffer)
        free(vd_info->tmp_buffer);
    vd_info->frame_buffer = NULL;

    /*it is a good thing to unmap!*/
    for(i= 0;i< NB_BUFFER;i++)
    {
        if(-1 == munmap(vd_info->mem[i],vd_info->buf.length))
        {
            perror("unmap:");
        }
    }
    close(vd_info->fd);
}

int V4l2::v4l2_init(struct video_information *vd_info, unsigned int format, unsigned int width, unsigned int height)
{
    int i;
    /*initialize the given data*/
    vd_info->format = format;
    vd_info->width = width;
    vd_info->height = height;
    vd_info->is_quit = 1;
    vd_info->frame_size_in = (vd_info->width * vd_info->height << 1);   //这个參数不清楚

    /*分配内存,因为YUYV是一种原始数据,可以直接显示,不需要编解码,而mjpeg格式的,需要解码,所以要分配两个缓冲区*/
    switch(vd_info->format)
    {
    case V4L2_PIX_FMT_MJPEG:
        vd_info->tmp_buffer = (unsigned char *)calloc(1,(size_t)vd_info->frame_size_in);
        if(vd_info->tmp_buffer == NULL)
        {
            perror("calloc tmp_buffer:");
        }
        vd_info->frame_buffer = (unsigned char *)calloc(1,(size_t)vd_info->width * (vd_info->height + 8)*2);//??这里分配的大小不懂
        if(vd_info->frame_buffer == NULL)
        {
            perror("calloc frame_buffer_mjpeg:");
        }
        break;
    case V4L2_PIX_FMT_YUYV:
        vd_info->frame_buffer = (unsigned char *)calloc(1,(size_t)vd_info->frame_size_in);
        if(vd_info->frame_buffer == NULL)
        {
            perror("calloc frame_buffer_yuyv");
        }
        break;
    default:
        return -1;
        break;
    }
    //打开,以阻塞方式打开.

    vd_info->fd = open(device,O_RDWR,0);
    if(vd_info->fd < 0)
        perror("open:");
    //
    /*VIDIOC_QUERYCAP.It is used to identify kernel devices compatible with this specification
    and to obtain information about driver and hardware capabilities.The ioctl takes a pointer
    to a struct v4l2_capability which is filled by the driver*/
    if(ioctl(vd_info->fd,VIDIOC_QUERYCAP,&vd_info->cap))
        perror("query camera failed:");
    //if(vd_info->cap.capabilities && V4L2_CAP_VIDEO_CAPTURE == 0)
    if(vd_info->cap.capabilities & V4L2_CAP_VIDEO_CAPTURE == 0)
    {
        perror("video capture not supported:");
        return -1;
    }
    /*set format*/
    v4l2_set_format(vd_info,width,height,format);
    /*set param*/
    v4l2_set_streamParam(vd_info);
    /*request buffers*/
    memset(&vd_info->rb,0,sizeof(struct v4l2_requestbuffers));
    vd_info->rb.count = NB_BUFFER;
    vd_info->rb.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    vd_info->rb.memory = V4L2_MEMORY_MMAP;
    /*VIDIOC_REQBUFS：分配内存*/
    if(-1 == ioctl(vd_info->fd,VIDIOC_REQBUFS,&vd_info->rb))
    {
        perror("request_buffer:");
    }
    /*map the buffers(4 buffer)映射到用戶空间内存*/
    for(i = 0;i< NB_BUFFER;i++)
    {
        memset(&vd_info->buf,0,sizeof(struct v4l2_buffer));
        vd_info->buf.index = i;
        vd_info->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        vd_info->buf.memory = V4L2_MEMORY_MMAP;
        /*mmap()系统调用使得进程之间通过映射同一个普通文件实现共享内存。普通文件
        被映射到进程地址空间后，进程可以像访问普通内存一样对文件进行访问，不必在调
        用read()，write()等操作。两个不同进程A、B共享内存的意思是，同一块物理内
        存被映射到进程A、B各自的进程地址空间。进程A可以即时访问进程B对共享内存中
        数据的更新，反之亦然。*/
        /*VIDIOC_QUERYBUF：把VIDIOC_REQBUFS中分配的数据缓存转换成物理地址*/
        if(-1 == ioctl(vd_info->fd,VIDIOC_QUERYBUF,&vd_info->buf))
        {
            perror("QUERYBUF:");
        }
        /*map it,0 means anywhere把摄像头图像数据映射到进程内存中，
        也就是只要使用vd->mem指针就可以使用采集到的图像数据*/
        vd_info->mem[i] = mmap(0,vd_info->buf.length,PROT_READ,MAP_SHARED,
                               vd_info->fd,vd_info->buf.m.offset);
        /*MAP_FAILED */
        if(MAP_FAILED == vd_info->mem[i])
        {
            perror("mmap:");
        }
    }
    //queue the buffers 进入队列
    for(i = 0;i < NB_BUFFER;i++)
    {
        memset(&vd_info->buf,0,sizeof(struct v4l2_buffer));
        vd_info->buf.index = i;
        vd_info->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        vd_info->buf.memory = V4L2_MEMORY_MMAP;
        /*把数据从缓存中读取出来*/
        if(-1 == ioctl(vd_info->fd,VIDIOC_QBUF,&vd_info->buf))
        {
            perror("queue buffer:");
        }
    }
    return 0;
}

/*开始捕获(发出捕获信号)*/
int V4l2::v4l2_on(struct video_information *vd_info)
{
    vd_info->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    /*VIDIOC_STREAMON 开始视频的采集*/
    if(-1 == ioctl(vd_info->fd,VIDIOC_STREAMON,&vd_info->type))
    {
        perror("unable to start capture");
        return -1;
    }
    vd_info->is_streaming = 1;
    return 0;
}

int V4l2::v4l2_just_close(struct video_information *vd_info)
{
    close(vd_info->fd);
    return 0;
}

int V4l2::v4l2_off(struct video_information *vd_info)
{
    vd_info->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    /*结束视频显示函数  VIDIOC_STREAMOFF*/
    if(-1 == ioctl(vd_info->fd,VIDIOC_STREAMOFF,&vd_info->type))
    {
        perror("v4l2_off:");
        return -1;
    }
    vd_info->is_streaming = 0;
    return 0;
}

/*采集(从缓冲区队列中取出数据，再将数据的内存复制另一内存区)*/
int V4l2::v4l2_grab(struct video_information *vd_info)
{
#define HEADFRAME1 0xaf
	static int count = 0;
	if(!vd_info->is_streaming)  //is stream is off,start it
	{
		if(v4l2_on(vd_info) != 0)   //failed
		{
			goto err;
		}
	}
	memset(&vd_info->buf,0,sizeof(struct v4l2_buffer));
	vd_info->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	vd_info->buf.memory = V4L2_MEMORY_MMAP;
	/*get data from buffers*/
	/*出队列以取得已采集数据的帧缓冲，取得原始采集数据。VIDIOC_DQBUF*/
	if(-1 == ioctl(vd_info->fd,VIDIOC_DQBUF,&vd_info->buf))
	{
		perror("get data from buffers:");
		goto err;
	}
	switch(vd_info->format)
	{
		case V4L2_PIX_FMT_MJPEG:
			if(vd_info->buf.bytesused <= HEADFRAME1)
			{
				return 0;
			}
			/*we can save tmp_buff to a jpg file,just write it!*/
			memcpy(vd_info->tmp_buffer,vd_info->mem[vd_info->buf.index],vd_info->buf.bytesused);
			/*decode MJPEG,so we can display it*/
			if(jpeg_decode(&vd_info->frame_buffer,vd_info->tmp_buffer,&vd_info->width,&vd_info->height)<0)
			{
				goto err;
			}
			break;
		case V4L2_PIX_FMT_YUYV:
			if(vd_info->buf.bytesused > vd_info->frame_size_in)
				memcpy(vd_info->frame_buffer,vd_info->mem[vd_info->buf.index],
						(size_t)vd_info->frame_size_in);
			else
				memcpy(vd_info->frame_buffer,vd_info->mem[vd_info->buf.index],
						(size_t)vd_info->buf.bytesused);
			break;
		default:
			goto err;
			break;
	}
	if(-1 == ioctl(vd_info->fd,VIDIOC_QBUF,&vd_info->buf))
	{
		perror("queue buffer again:");
		goto err;
	}
	return 0;
err:
	vd_info->is_quit = 0;
	return -1;
}
