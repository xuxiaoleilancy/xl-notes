#include "mainwindow.h"
#include <QApplication>

#include <QLabel>
#include <QHBoxLayout>
#include <QPixmap>


#include "opengl/GLYuvWidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    GLYuvWidget yuv_widget;

    QLabel label;
	label.setScaledContents(true);
	QHBoxLayout hLay;
	hLay.addWidget(&label);
    yuv_widget.setLayout(&hLay);

//	QPixmap pix(w.size());
//	pix.fill(Qt::transparent);
//	QPainter p(&pix);
//	p.setRenderHint(QPainter::Antialiasing);
//	p.setPen(QPen(Qt::yellow,4));
//	p.drawRoundRect(w.rect().adjusted(20,20,-20,-20));
//	label.setPixmap(pix);

    yuv_widget.show();

    QObject::connect(&w,SIGNAL(sigYuv(uchar*,int,int))
                     ,&yuv_widget,SLOT(slotShowYuv(uchar*,int,int)));



    return a.exec();
}
