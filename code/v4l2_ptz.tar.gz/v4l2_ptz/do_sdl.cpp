#include "do_sdl.h"
#include <linux/videodev2.h>


SDL::SDL():
    window(NULL),
    renderer(NULL),
    texture(NULL),
    cur_w(-1),
    cur_h(-1),
    FP_YUV(NULL)
{
FP_YUV = fopen("1.yuv","wb");
}
SDL::~SDL()
{
    if(FP_YUV)
    {
        fclose(FP_YUV);
        FP_YUV = NULL;
    }

}



int SDL::sdl_init(int32_t _captureVideoType, int width, int height)
{
    if(SDL_Init(SDL_INIT_VIDEO)<0)
    {
        perror("sdl_init:");
        return -1;
    }

    cur_w = width;
    cur_h = height;
    if(SDL_CreateWindowAndRenderer(cur_w
                                , cur_h
                                , SDL_WINDOW_RESIZABLE | SDL_WINDOW_OPENGL
                                , &window
                                , &renderer
                                ) < 0)
    {
        perror("SDL_CreateWindowAndRenderer:");
        return -1;
    }

    m_captureVideoType = _captureVideoType;

    if(m_captureVideoType == V4L2_PIX_FMT_YUYV)
    {
        texture = SDL_CreateTexture(renderer
                                    ,SDL_PIXELFORMAT_YUY2
                                    ,SDL_TEXTUREACCESS_STREAMING
                                    ,cur_w
                                    ,cur_h);
        if(NULL == texture)
        {
            printf("SDL_CreateTexture failed :%s \n",SDL_GetError());
            return -1;
        }

    }
    else if(m_captureVideoType == V4L2_PIX_FMT_MJPEG)
    {


    }
    else if(m_captureVideoType == V4L2_PIX_FMT_YUV420)
    {
        texture = SDL_CreateTexture(renderer
                                    ,SDL_PIXELFORMAT_IYUV
                                    ,SDL_TEXTUREACCESS_STREAMING
                                    ,cur_w
                                    ,cur_h);
        if(NULL == texture)
        {
            printf("SDL_CreateTexture failed :%s \n",SDL_GetError());
            return -1;
        }
    }

    /*Get the number of milliseconds since the SDL library initialization*/
    lasttime = SDL_GetTicks();

    return 0;
}
int SDL::sdl_uninit()
{
    if(renderer)
    {
        SDL_DestroyRenderer(renderer);
        renderer = NULL;
    }

    if(window)
    {
        SDL_DestroyWindow(window);
        window = NULL;
    }


    if(m_captureVideoType == V4L2_PIX_FMT_YUYV)
    {
        if(texture)
        {
            SDL_DestroyTexture(texture);
            texture = NULL;
        }

    }
    else if(m_captureVideoType == V4L2_PIX_FMT_MJPEG)
    {

    }
     else if(m_captureVideoType == V4L2_PIX_FMT_YUV420)
    {
        if(texture)
        {
            SDL_DestroyTexture(texture);
            texture = NULL;
        }
    }


    SDL_Quit();

    return 0;
}



int SDL::sdl_showMovie(unsigned char * buffer, int len)
{

    while(SDL_PollEvent(&sdlevent))
    {
        if(sdlevent.type == SDL_QUIT)
        {
            //vd_info->is_quit = 0;
            break;
        }
    }

    currtime = SDL_GetTicks();
    if(currtime - lasttime > 0)
    {
        frmrate = 1000/(currtime - lasttime);
        //printf("%dframe pre second\n",frmrate);
    }
    lasttime = currtime;


    if(m_captureVideoType == V4L2_PIX_FMT_YUYV)
    {
       draw_yuyv(buffer, len);
    }
    else if(m_captureVideoType == V4L2_PIX_FMT_MJPEG)
    {
       draw_mjpeg(buffer, len);
    }
    if(m_captureVideoType == V4L2_PIX_FMT_YUV420)
    {
//        if(FP_YUV)
//        {
//            fwrite(buffer, 1, len, FP_YUV);
//        }

       draw_yuyv(buffer, len);
    }

    return 0;
}

int SDL::draw_yuyv(unsigned char * buffer, int len)
{
    int pitch = 0;
    void * pixels;
    if(SDL_LockTexture(texture, NULL,&pixels, &pitch) < 0)
    {
        printf("SDL_LockTexture is err :%s \n",SDL_GetError());
        return -1;
    }

    memcpy(pixels, buffer, len);

    SDL_UnlockTexture(texture);


    if(SDL_RenderCopy(renderer, texture, NULL, NULL) < 0)
    {
        printf("SDL_RenderCopy is err :%s \n",SDL_GetError());
        return -1;
    }

    SDL_RenderPresent(renderer);

    return 0;
}
int SDL::draw_mjpeg(unsigned char * buffer, int len)
{
    SDL_RWops * rw = NULL;
    SDL_Surface * image = NULL;

    if(!IMG_Init(IMG_INIT_JPG))
     {
        printf("Unable to initialize IMG\n");
        return -1;
    }

    rw = SDL_RWFromMem(buffer, len);
    if(rw == NULL)
    {
        printf("SDL_RWFromMem is err :%s \n",SDL_GetError());
        return -1;
    }

    image = IMG_Load_RW(rw, 0);
    if(image == NULL)
    {
        printf("IMG_Load is err :%s \n",SDL_GetError());
        return -1;
    }

    texture = SDL_CreateTextureFromSurface(renderer, image);
    if(texture == NULL)
    {
        printf("SDL_CreateTextureFromSurface is err :%s \n",SDL_GetError());
        return -1;
    }

    if(SDL_RenderCopy(renderer, texture, NULL, NULL) < 0)
    {
        printf("SDL_RenderCopy is err :%s \n",SDL_GetError());
        return -1;
    }
    SDL_RenderPresent(renderer);


    IMG_Quit();

    if(texture)
    {
        SDL_DestroyTexture(texture);
        texture = NULL;
    }

    if(rw)
    {
        SDL_RWclose(rw);
        rw = NULL;
    }

    if(image)
    {
        SDL_FreeSurface(image);
        image = NULL;
    }

    return 0;
}
