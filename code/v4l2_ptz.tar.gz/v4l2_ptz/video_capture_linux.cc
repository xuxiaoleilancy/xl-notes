/*
 *  Copyright (c) 2012 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include <errno.h>
#include <fcntl.h>
#include <linux/videodev2.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sched.h>

#include <iostream>
#include <new>

#include "video_capture_linux.h"
#include "webrtc/system_wrappers/interface/critical_section_wrapper.h"
#include "webrtc/system_wrappers/interface/ref_count.h"
#include "webrtc/system_wrappers/interface/thread_wrapper.h"
#include "webrtc/system_wrappers/interface/trace.h"



namespace webrtc
{
	int isv4l2Control(int fd, int control,struct v4l2_queryctrl *queryctrl);
	int v4l2SetDefault(int fd, int control)
	{
		struct v4l2_control control_s;
		struct v4l2_queryctrl queryctrl;
		int min, max, step, val_def;
		int err;
		if (isv4l2Control(fd, control, &queryctrl) < 0)
			return -1;
		min = queryctrl.minimum;
		max = queryctrl.maximum;
		step = queryctrl.step;
		val_def = queryctrl.default_value;

		control_s.id = control;
		control_s.value = val_def;

		if ((err = ioctl(fd, VIDIOC_S_CTRL, &control_s)) < 0) {
			printf("ioctl set control error\n");
			return -1;
		}

		return 0;
	}
	int v4l2SetPtzToHome(int fd)
	{
		int err;

		err = v4l2SetDefault(fd, V4L2_CID_PAN_ABSOLUTE);
		if(err != 0)
			return err;

		err = v4l2SetDefault(fd, V4L2_CID_TILT_ABSOLUTE);
		if(err != 0)
			return err;

		err = v4l2SetDefault(fd, V4L2_CID_ZOOM_ABSOLUTE);
		if(err != 0)
			return err;
		//err = v4l2SetControl(fd, V4L2_CID_FOCUS_AUTO, 1);
		err = v4l2SetDefault(fd, V4L2_CID_FOCUS_AUTO);
		if(err != 0)
			return err;

		err = v4l2SetDefault(fd, V4L2_CID_FOCUS_ABSOLUTE);
		if(err != 0)
			return err;

		return 0;
	}
	int isv4l2Control(int fd, int control,
			struct v4l2_queryctrl *queryctrl)
	{
		int err =0;
		queryctrl->id = control;
		if ((err= ioctl(fd, VIDIOC_QUERYCTRL, queryctrl)) < 0) {
			perror("ioctl querycontrol error");
		} else if (queryctrl->flags & V4L2_CTRL_FLAG_DISABLED) {
			printf("control %s disabled\n", (char *) queryctrl->name);
		} else if (queryctrl->flags & V4L2_CTRL_TYPE_BOOLEAN) {
			return 1;
		} else if (queryctrl->type & V4L2_CTRL_TYPE_INTEGER) {
			return 0;
		} else {
			printf("contol %s unsupported\n", (char *) queryctrl->name);
		}
		return -1;
	}
	int v4l2SetControl(int fd, int control, int value)
	{
		struct v4l2_control control_s;
		struct v4l2_queryctrl queryctrl;
		int min, max, step, val_def;
		int err;
		if (isv4l2Control(fd, control, &queryctrl) < 0)
			return -1;
		min = queryctrl.minimum;
		max = queryctrl.maximum;
		step = queryctrl.step;
		val_def = queryctrl.default_value;
		if ((value >= min) && (value <= max)) {
			control_s.id = control;
			control_s.value = value;
			if ((err = ioctl(fd, VIDIOC_S_CTRL, &control_s)) < 0) {
				printf("ioctl set control error\n");
				return -1;
			}
		}
		else
		{
			printf("set value error\n");
		}
		return 0;
	}

VideoCaptureModuleV4L2::VideoCaptureModuleV4L2(const int32_t id, SDL *sdl,YuvCallBack *yuv):
        mysdl(sdl),
      _captureThread(NULL),
      _captureCritSect(CriticalSectionWrapper::CreateCriticalSection()),
      _cameraCtrlCritsect(CriticalSectionWrapper::CreateCriticalSection()),
      _deviceId(-1), 
      _deviceFd(-1),
      _buffersAllocatedByDevice(-1),
      _currentWidth(-1), 
      _currentHeight(-1),
      _currentFrameRate(-1),
      _captureVideoType(0),
      _captureStarted(false),
      _pool(NULL),
      _yuv(yuv)
{
}

int32_t VideoCaptureModuleV4L2::Init(const char* deviceUniqueIdUTF8)
{

    _deviceId = 0; //store the device id
    return 0;
}

VideoCaptureModuleV4L2::~VideoCaptureModuleV4L2()
{
    StopCapture();
    if (_captureCritSect)
    {
        delete _captureCritSect;
    }
    if (_cameraCtrlCritsect)
    {
        delete _cameraCtrlCritsect;
    }
    if (_deviceFd != -1)
    close(_deviceFd);
}
void VideoCaptureModuleV4L2::UpdateFrameCount()
{
    struct timeval t_now;
    if (_incomingFrameTimes[0] == 0)
    {
        // first no shift
    }
    else
    {
        // shift

        for (int i = (kFrameRateCountHistorySize - 2); i >= 0; i--)
        {
            _incomingFrameTimes[i + 1] = _incomingFrameTimes[i];
        }
    }

    gettimeofday(&t_now, NULL);
    _incomingFrameTimes[0] = t_now.tv_sec*1000+ t_now.tv_usec/1000;
}
uint32_t VideoCaptureModuleV4L2::CalculateFrameRate(const TickTime& now)
{
    int32_t num = 0;
    int32_t nrOfFrames = 0;
    struct timeval t_now;
    uint64_t now_millisec;
    gettimeofday(&t_now,NULL);

    now_millisec = t_now.tv_sec*1000 + t_now.tv_usec/1000;
    for (num = 1; num < (kFrameRateCountHistorySize - 1); num++)
    {
        if (_incomingFrameTimes[num] <= 0
            || (now_millisec - _incomingFrameTimes[num]) > kFrameRateHistoryWindowMs) // don't use data older than 2sec
        {
            break;
        }
        else
        {
            nrOfFrames++;
        }
    }
    if (num > 1)
    {
        int64_t diff = now_millisec - _incomingFrameTimes[num - 1];
        if (diff > 0)
        {
            return uint32_t((nrOfFrames * 1000.0f / diff) + 0.5f);
        }
    }

    return nrOfFrames;
}


int VideoCaptureModuleV4L2::setCameraCtrl(stCameraPTZ myctrl)
{
    CriticalSectionScoped cs(_cameraCtrlCritsect);

	camera_ptz.push_back(myctrl);

    return 0;
}
int32_t VideoCaptureModuleV4L2::StartCapture(const char* device_name,unsigned int format,unsigned int width,unsigned int height)
{
    if (_captureStarted)
    {
            return 0;
    }

    CriticalSectionScoped cs(_captureCritSect);
    //first open /dev/video device
    char device[20];
    //sprintf(device, "/dev/video%d", (int) _deviceId);

    int fd;

    /* detect /dev/video [0-63] entries */
//    int n;
//    for (n = 0; n < 64; n++)
//    {
//		memset(device, 0, 20);
//        sprintf(device, "/dev/video%d", n);
//        if ((fd = open(device, O_RDONLY)) != -1)
//        {
//            // query device capabilities
//            struct v4l2_capability cap;
//            if (ioctl(fd, VIDIOC_QUERYCAP, &cap) == 0)
//            {
//				close(fd);
//				break; // fd matches with device unique id supplied
//            }
//            close(fd); // close since this is not the matching device
//        }
//    }

     //sprintf(device, "/dev/video%d", 0);

    //if ((_deviceFd = open(device, O_RDWR | O_NONBLOCK, 0)) < 0)
    if ((_deviceFd = open(device_name, O_RDWR, 0)) < 0)
    {
      WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,
                   "error in opening %s errono = %d", device, errno);
        return -1;
    }


	const int nFormats = 4;
	unsigned int fmts[nFormats];


#if 1
    fmts[0] = V4L2_PIX_FMT_YUYV;
    fmts[1] = V4L2_PIX_FMT_JPEG;
     fmts[2] = V4L2_PIX_FMT_YUV420;
    fmts[3] = V4L2_PIX_FMT_MJPEG;
#else
    fmts[0] = V4L2_PIX_FMT_MJPEG;
    fmts[1] = V4L2_PIX_FMT_YUV420;
     fmts[2] = V4L2_PIX_FMT_YUYV;
    fmts[3] = V4L2_PIX_FMT_JPEG;
#endif

	// Enumerate image formats.
	struct v4l2_fmtdesc fmt;
	int fmtsIdx = nFormats;
	memset(&fmt, 0, sizeof(fmt));
	fmt.index = 0;
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	printf("Video Capture enumerats supported image formats:\n");
	while (ioctl(_deviceFd, VIDIOC_ENUM_FMT, &fmt) == 0) {
		printf("  { pixelformat = %c%c%c%c, description = '%s' }\n",
                fmt.pixelformat & 0xFF, (fmt.pixelformat>>8) & 0xFF,
				(fmt.pixelformat>>16) & 0xFF, (fmt.pixelformat>>24) & 0xFF,
				fmt.description);
		// Match the preferred order.
		for (int i = 0; i < nFormats; i++) {
			if (fmt.pixelformat == fmts[i] && i < fmtsIdx)
				fmtsIdx = i;
		}
		// Keep enumerating.
		fmt.index++;
	}

	if (fmtsIdx == nFormats)
	{
		printf("no supporting video formats found\n");
		return -1;
	} else {
		printf("We prefer format %c%c%c%c\n",
				fmts[fmtsIdx] & 0xFF, (fmts[fmtsIdx]>>8) & 0xFF,
				(fmts[fmtsIdx]>>16) & 0xFF, (fmts[fmtsIdx]>>24) & 0xFF);
	}

    struct v4l2_format video_fmt;
    memset(&video_fmt, 0, sizeof(struct v4l2_format));
    video_fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    video_fmt.fmt.pix.sizeimage = 0;
    video_fmt.fmt.pix.width = width;
    video_fmt.fmt.pix.height = height;
    video_fmt.fmt.pix.pixelformat = fmts[fmtsIdx];
    //video_fmt.fmt.pix.field       = V4L2_FIELD_INTERLACED;

	
	if (video_fmt.fmt.pix.pixelformat == V4L2_PIX_FMT_YUYV)
	{
        printf("_captureVideoType is kVideoYUY2\n");
        _captureVideoType = V4L2_PIX_FMT_YUYV;
	}
	else if (video_fmt.fmt.pix.pixelformat == V4L2_PIX_FMT_YUV420)
	{
        printf("_captureVideoType is kVideoI420\n");
        _captureVideoType = V4L2_PIX_FMT_YUV420;
	}
	else if (video_fmt.fmt.pix.pixelformat == V4L2_PIX_FMT_MJPEG ||
			video_fmt.fmt.pix.pixelformat == V4L2_PIX_FMT_JPEG)
	{
        printf("_captureVideoType is kVideoMJPEG\n");
        _captureVideoType = V4L2_PIX_FMT_MJPEG;
	}


    //set format and frame size now
    if (ioctl(_deviceFd, VIDIOC_S_FMT, &video_fmt) < 0)
    {
       printf("error in VIDIOC_S_FMT, errno = %d\n", errno);
        return -1;
    }

    // initialize current width and height
    _currentWidth = video_fmt.fmt.pix.width;
    _currentHeight = video_fmt.fmt.pix.height;
    //_captureDelay = 120;

    printf("_currentWidth:%d _currentHeight=%d\n",_currentWidth,_currentHeight);
    mysdl->sdl_init(_captureVideoType,_currentWidth,_currentHeight);



    // Trying to set frame rate, before check driver capability.
    bool driver_framerate_support = true;
    struct v4l2_streamparm streamparms;
    memset(&streamparms, 0, sizeof(streamparms));
    streamparms.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(_deviceFd, VIDIOC_G_PARM, &streamparms) < 0) {
        printf("error in VIDIOC_G_PARM errno = %d\n", errno);
        driver_framerate_support = false;
      // continue
    }
    else
    {
		printf("\n  Frame rate:   %u/%u\n",
				  	streamparms.parm.capture.timeperframe.denominator,
				   		   streamparms.parm.capture.timeperframe.numerator);

      // check the capability flag is set to V4L2_CAP_TIMEPERFRAME.
      if (streamparms.parm.capture.capability == V4L2_CAP_TIMEPERFRAME) 
	  {
        // driver supports the feature.int setCameraCtrl(camera_ctrl myctrl); Set required framerate.
        memset(&streamparms, 0, sizeof(streamparms));
        streamparms.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        streamparms.parm.capture.timeperframe.numerator = 1;
        streamparms.parm.capture.timeperframe.denominator = 30;
        if (ioctl(_deviceFd, VIDIOC_S_PARM, &streamparms) < 0)
        {
            printf("Failed to set the framerate. errno=%d\n", errno);
          driver_framerate_support = false;
        }
        else
        {
          _currentFrameRate = 30;
        }
      }
    }


    if (!AllocateVideoBuffers())
    {
        printf("failed to allocate video capture buffers\n");
        return -1;
    }
	// fix V50U  视频设备打开和读取视频流之间加入延时100ms,解决入会调用摄像头时，USB3.0掉线问题
	usleep(100000);

//	unsigned int i;
//	for(i= 0; i < _buffersAllocatedByDevice; ++i)
//	{
//		struct v4l2_buffer buf;
//        memset(&buf, 0, sizeof(v4l2_buffer));

//		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
//		buf.memory = V4L2_MEMORY_MMAP;
//		buf.index = i;

//		if (ioctl (fd, VIDIOC_QBUF, &buf) < 0)
//		{
//            printf( "error in VIDIOC_QBUF, errno = %s\n", strerror(errno));
//			return -1;
//		}
//	}

    // Needed t  start UVC camera - from the uvcview application
    enum v4l2_buf_type type;
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(_deviceFd, VIDIOC_STREAMON, &type) == -1)
    {
       printf("Failed to turn on stream\n");
        return -1;
    }



    //start capture thread;
    if (!_captureThread)
    {
        _captureThread = ThreadWrapper::CreateThread(
            VideoCaptureModuleV4L2::CaptureThread, this, kHighPriority);
        unsigned int id;
        _captureThread->Start(id);
    }

    _captureStarted = true;
    return 0;
}

int32_t VideoCaptureModuleV4L2::StopCapture()
{
    if (_captureThread) {
        // Make sure the capture thread stop stop using the critsect.
        _captureThread->SetNotAlive();
        if (_captureThread->Stop()) {
            delete _captureThread;
            _captureThread = NULL;
        } else
        {
            // Couldn't stop the thread, leak instead of crash.
            WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, -1,
                         "%s: could not stop capture thread", __FUNCTION__);
            assert(false);
        }
    }

    if (_captureStarted)
    {
        _captureStarted = false;
        _captureThread = NULL;

        DeAllocateVideoBuffers();
        close(_deviceFd);
        _deviceFd = -1;
    }
	if(camera_ptz.size() != 0)
	{    
		camera_ptz.clear();
	} 

    return 0;
}

//critical section protected by the caller

bool VideoCaptureModuleV4L2::AllocateVideoBuffers()
{
    struct v4l2_requestbuffers rbuffer;
    memset(&rbuffer, 0, sizeof(v4l2_requestbuffers));

    rbuffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    rbuffer.memory = V4L2_MEMORY_MMAP;
    rbuffer.count = kNoOfV4L2Bufffers;

    if (ioctl(_deviceFd, VIDIOC_REQBUFS, &rbuffer) < 0)
    {
        WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,
                   "Could not get buffers from device. errno = %d", errno);
        return false;
    }

    if (rbuffer.count > kNoOfV4L2Bufffers)
        rbuffer.count = kNoOfV4L2Bufffers;

    _buffersAllocatedByDevice = rbuffer.count;

    //Map the buffers
    _pool = new Buffer[rbuffer.count];

    for (unsigned int i = 0; i < rbuffer.count; i++)
    {
        struct v4l2_buffer buffer;
        memset(&buffer, 0, sizeof(v4l2_buffer));
        buffer.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buffer.memory = V4L2_MEMORY_MMAP;
        buffer.index = i;

        if (ioctl(_deviceFd, VIDIOC_QUERYBUF, &buffer) < 0)
        {
            return false;
        }

        _pool[i].start = mmap(NULL, buffer.length, PROT_READ | PROT_WRITE, MAP_SHARED,
                              _deviceFd, buffer.m.offset);

        if (MAP_FAILED == _pool[i].start)
        {
            for (unsigned int j = 0; j < i; j++)
                munmap(_pool[j].start, _pool[j].length);
            return false;
        }

        _pool[i].length = buffer.length;

        if (ioctl (_deviceFd, VIDIOC_QBUF, &buffer) < 0)
        {
            printf( "error in VIDIOC_QBUF, errno = %s\n", strerror(errno));
            return -1;
        }
    }
    return true;
}

bool VideoCaptureModuleV4L2::DeAllocateVideoBuffers()
{

    // turn off stream
    enum v4l2_buf_type type;
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(_deviceFd, VIDIOC_STREAMOFF, &type) < 0)
    {
        WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,
                   "VIDIOC_STREAMOFF error. errno: %d", errno);
    }

    // unmap buffers
    for (int i = 0; i < _buffersAllocatedByDevice; i++)
        munmap(_pool[i].start, _pool[i].length);

    delete[] _pool;

    return true;
}

bool VideoCaptureModuleV4L2::CaptureStarted()
{
    return _captureStarted;
}

bool VideoCaptureModuleV4L2::CaptureThread(void* obj)
{
    return static_cast<VideoCaptureModuleV4L2*> (obj)->CaptureProcess();
}
bool VideoCaptureModuleV4L2::CaptureProcess()
{
    int retVal = 0;
    fd_set rSet;

    _captureCritSect->Enter();

    FD_ZERO(&rSet);
    FD_SET(_deviceFd, &rSet);

    struct timeval timeout;
    timeout.tv_sec = 2;
    timeout.tv_usec = 0;

    retVal = select(_deviceFd + 1, &rSet, NULL, NULL, &timeout);
    if (retVal < 0 && errno != EINTR) // continue if interrupted
    {
        // select failed
        _captureCritSect->Leave();
        WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,"select retVal < 0");
        return false;
    }
    else if (retVal == 0)
    {
        // select timed out
        WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,"select retVal == 0");
        _captureCritSect->Leave();
        return true;
    }
    else if (!FD_ISSET(_deviceFd, &rSet))
    {
        // not event on camera handle
        WEBRTC_TRACE(webrtc::kTraceError, webrtc::kTraceVideoCapture, _id,"not event on camera handle");
        _captureCritSect->Leave();
        return true;
    }
    struct timeval t_now;
    uint64_t now_millisec;
	uint32_t  frameRate=0;
    gettimeofday(&t_now,NULL);

    now_millisec = t_now.tv_sec*1000 + t_now.tv_usec/1000;

    //total_log("capture","millisecond=%ld",(now_millisec - _lastFrameRateCallbackTime));
    if ((now_millisec - _lastFrameRateCallbackTime)
        > kFrameRateCallbackInterval)
    {
		const TickTime now;
    	frameRate = CalculateFrameRate(now);
		//WEBRTC_TRACE(webrtc::kTraceInfo,webrtc::kTraceVideoCapture,_id,",_currentFrameRate=%d,frame rate:%d",_currentFrameRate,frameRate);
		printf("_currentFrameRate=%d,frame rate:%d\n",_currentFrameRate,frameRate);
		_lastFrameRateCallbackTime = now_millisec; // Can be set by EnableFrameRateCallback
    	_curCalcFrameRate = frameRate;
	}
    if (_captureStarted)
    {
        struct v4l2_buffer buf;
        memset(&buf, 0, sizeof(struct v4l2_buffer));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        // dequeue a buffer - repeat until dequeued properly!
        while (ioctl(_deviceFd, VIDIOC_DQBUF, &buf) < 0)
        {
            if (errno != EINTR)
            {

                printf("could not sync on a buffer on device %s\n", strerror(errno));
                _captureCritSect->Leave();
                return true;
            }
        }
		



//        VideoCaptureCapability frameInfo;
//        frameInfo.width = _currentWidth;
//        frameInfo.height = _currentHeight;
//        //frameInfo.rawType = _captureVideoType;

        // convert to to I420 if needed
		UpdateFrameCount();
//        IncomingFrame((unsigned char*) _pool[buf.index].start,
//                      buf.bytesused, frameInfo);
        // enqueue the buffer again
        mysdl->sdl_showMovie((unsigned char*) _pool[buf.index].start, buf.bytesused);

//        if(_yuv)
//        {
//            _yuv->yuv_callback((unsigned char*) _pool[buf.index].start, buf.bytesused,_currentWidth,_currentHeight);
//        }

        if (ioctl(_deviceFd, VIDIOC_QBUF, &buf) == -1)
        {
            printf("Failed to enqueue capture buffer\n");
        }
    }
    _captureCritSect->Leave();
	//sched_yield();
    //usleep(0);

	stCameraPTZ *ptr = NULL;
	{
    	CriticalSectionScoped cs(_cameraCtrlCritsect);

		if(camera_ptz.size() != 0)
		{
			ptr = &camera_ptz.front();
			camera_ptz.pop_front();
		}

	}
	if(ptr)
	{
		if(strncmp(ptr->current_ctrl_type, "pan", 3) ==  0)
		{

			int err;
			err = v4l2SetControl(_deviceFd, V4L2_CID_PAN_SPEED, ptr->value);
			if (err  < 0)
			{
				printf("v4l2 set pan left/right control error\n");
				//return -1;
			}
			//return 0;

		}
        if(strncmp(ptr->current_ctrl_type, "home", 4) ==  0)
        {

            int err;
            v4l2SetPtzToHome(_deviceFd);
            //return 0;

        }
        if(strncmp(ptr->current_ctrl_type, "tilt", 4) ==  0)
        {

            int err;
            err = v4l2SetControl(_deviceFd, V4L2_CID_TILT_SPEED, ptr->value);
            if (err  < 0)
            {
                printf("v4l2 set pan left/right control error\n");
                //return -1;
            }

        }
        if(strncmp(ptr->current_ctrl_type, "zoom", 4) ==  0)
        {

            int err;
            err = v4l2SetControl(_deviceFd, V4L2_CID_ZOOM_CONTINUOUS, ptr->value);
            if (err  < 0)
            {
                printf("v4l2 set pan left/right control error\n");
                //return -1;
            }

        }
	}
    ptr =NULL;


    return true;
}




}  // namespace webrtc
